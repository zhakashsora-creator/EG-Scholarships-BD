module.exports=[80822,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_documents_download_route_actions_0dkzwdt.js.map