module.exports=[36914,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_consultant_route_actions_0lql2vd.js.map