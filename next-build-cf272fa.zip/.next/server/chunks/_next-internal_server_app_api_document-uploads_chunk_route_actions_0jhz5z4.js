module.exports=[42140,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_document-uploads_chunk_route_actions_0jhz5z4.js.map