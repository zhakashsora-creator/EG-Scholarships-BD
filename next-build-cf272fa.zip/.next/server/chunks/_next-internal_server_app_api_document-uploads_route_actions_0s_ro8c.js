module.exports=[26364,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_document-uploads_route_actions_0s_ro8c.js.map