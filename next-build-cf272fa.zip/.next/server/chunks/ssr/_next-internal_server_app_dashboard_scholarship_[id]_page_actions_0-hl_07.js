module.exports=[76856,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_dashboard_scholarship_%5Bid%5D_page_actions_0-hl_07.js.map