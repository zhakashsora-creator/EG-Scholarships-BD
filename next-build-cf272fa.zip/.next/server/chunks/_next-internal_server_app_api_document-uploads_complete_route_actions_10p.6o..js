module.exports=[11720,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_document-uploads_complete_route_actions_10p.6o..js.map