globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/QTwPgyC9ywo5sphRLTzUR/_buildManifest.js",
    "static/QTwPgyC9ywo5sphRLTzUR/_ssgManifest.js",
    "static/QTwPgyC9ywo5sphRLTzUR/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0w1za-v0n0i5d.js",
    "static/chunks/01k6-1ujkykis.js",
    "static/chunks/0zgf-keq3gwii.js",
    "static/chunks/0j-g-1fv6z413.js",
    "static/chunks/turbopack-0~2v.zufir65u.js"
  ]
};
