var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__042fnqb._.js")
R.c("server/chunks/ssr/0rsw_next_dist_esm_build_templates_app-page_0egsf~c.js")
R.c("server/chunks/ssr/[root-of-the-server]__048pnyn._.js")
R.c("server/chunks/ssr/0rsw_next_dist_0w37pm2._.js")
R.c("server/chunks/ssr/0rsw_next_dist_client_components_builtin_global-error_0n.muds.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0k77kol.js")
R.m(91563)
module.exports=R.m(91563).exports
