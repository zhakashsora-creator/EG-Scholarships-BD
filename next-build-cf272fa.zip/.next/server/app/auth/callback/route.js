var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__0vtpkpa._.js")
R.c("server/chunks/[root-of-the-server]__0.tn9k7._.js")
R.c("server/chunks/_next-internal_server_app_auth_callback_route_actions_09jr~mp.js")
R.m(28608)
module.exports=R.m(28608).exports
