var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/signout/route.js")
R.c("server/chunks/[root-of-the-server]__0vcgzdk._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_next-internal_server_app_auth_signout_route_actions_0ev_66n.js")
R.m(52370)
module.exports=R.m(52370).exports
