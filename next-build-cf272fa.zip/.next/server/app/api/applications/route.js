var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/applications/route.js")
R.c("server/chunks/0rsw_next_dist_esm_build_templates_app-route_0w6gmlm.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_next-internal_server_app_api_applications_route_actions_12-i~8k.js")
R.m(92117)
module.exports=R.m(92117).exports
