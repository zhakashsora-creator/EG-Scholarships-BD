var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/consultant/route.js")
R.c("server/chunks/0rsw_next_dist_esm_build_templates_app-route_0wh356t.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/app_0_trpx3._.js")
R.c("server/chunks/_next-internal_server_app_api_consultant_route_actions_0lql2vd.js")
R.m(97937)
module.exports=R.m(97937).exports
