var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/courses/route.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/_0m45c5z._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/app_0_trpx3._.js")
R.c("server/chunks/_next-internal_server_app_api_courses_route_actions_0vn-ru~.js")
R.m(25912)
module.exports=R.m(25912).exports
