var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/report/route.js")
R.c("server/chunks/0rsw_next_dist_esm_build_templates_app-route_0~t9.s_.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/_02hclk0._.js")
R.c("server/chunks/_next-internal_server_app_api_report_route_actions_0ac8l29.js")
R.m(58800)
module.exports=R.m(58800).exports
