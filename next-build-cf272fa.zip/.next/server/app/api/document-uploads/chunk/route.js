var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/document-uploads/chunk/route.js")
R.c("server/chunks/_0uw0iqm._.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_next-internal_server_app_api_document-uploads_chunk_route_actions_0jhz5z4.js")
R.m(80497)
module.exports=R.m(80497).exports
