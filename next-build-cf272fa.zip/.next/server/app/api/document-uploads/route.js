var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/document-uploads/route.js")
R.c("server/chunks/_035y3w_._.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_next-internal_server_app_api_document-uploads_route_actions_0s_ro8c.js")
R.m(27108)
module.exports=R.m(27108).exports
