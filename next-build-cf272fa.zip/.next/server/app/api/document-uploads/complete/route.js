var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/document-uploads/complete/route.js")
R.c("server/chunks/_0sq_y6v._.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_next-internal_server_app_api_document-uploads_complete_route_actions_10p.6o..js")
R.m(96964)
module.exports=R.m(96964).exports
