var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/account/route.js")
R.c("server/chunks/0rsw_next_dist_esm_build_templates_app-route_0.4ad4n.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_next-internal_server_app_api_account_route_actions_0qw9yvj.js")
R.m(65036)
module.exports=R.m(65036).exports
