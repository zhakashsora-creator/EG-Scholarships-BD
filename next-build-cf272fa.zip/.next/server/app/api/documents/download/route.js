var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/download/route.js")
R.c("server/chunks/0rsw_next_dist_esm_build_templates_app-route_0dvv2.h.js")
R.c("server/chunks/[root-of-the-server]__0rvtjjw._.js")
R.c("server/chunks/_0j-7ee_._.js")
R.c("server/chunks/[root-of-the-server]__0iq_a9p._.js")
R.c("server/chunks/_next-internal_server_app_api_documents_download_route_actions_0dkzwdt.js")
R.m(40736)
module.exports=R.m(40736).exports
