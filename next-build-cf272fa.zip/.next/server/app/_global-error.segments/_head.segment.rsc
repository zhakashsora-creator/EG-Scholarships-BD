1:"$Sreact.fragment"
2:I[6391,["/_next/static/chunks/0pi6sxr_8rcpf.js","/_next/static/chunks/0dj1f-u_jn~hu.js"],"ViewportBoundary"]
3:I[6391,["/_next/static/chunks/0pi6sxr_8rcpf.js","/_next/static/chunks/0dj1f-u_jn~hu.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"QTwPgyC9ywo5sphRLTzUR"}
