1:"$Sreact.fragment"
2:I[39011,["/_next/static/chunks/0pi6sxr_8rcpf.js","/_next/static/chunks/0dj1f-u_jn~hu.js"],"default"]
3:I[37771,["/_next/static/chunks/0pi6sxr_8rcpf.js","/_next/static/chunks/0dj1f-u_jn~hu.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"QTwPgyC9ywo5sphRLTzUR"}
