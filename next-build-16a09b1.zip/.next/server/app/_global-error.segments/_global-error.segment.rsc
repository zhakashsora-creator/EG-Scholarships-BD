1:"$Sreact.fragment"
2:I[5544,[],""]
3:I[5694,[],""]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"8hMx2-h4ctU9_q6zC4HFj"}
