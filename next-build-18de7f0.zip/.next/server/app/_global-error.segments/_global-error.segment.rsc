1:"$Sreact.fragment"
2:I[6484,[],""]
3:I[562,[],""]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"mnCS7OYFIHJXPrGIj44IC"}
